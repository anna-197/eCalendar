 
        function openpopup() {
            document.getElementById("mypopup").style.display = "block";
          }
          
          function closepopup() {
            document.getElementById("mypopup").style.display = "none";
          }

          function openmonths() {
            document.getElementById("dropup-content").style.display="block";
          }

          function opendays() {
            document.getElementById("dropup-content-days").style.display="block";
          }

          function openmonths2() {
            document.getElementById("dropup-content2").style.display="block";
          }

          function opendays2() {
            document.getElementById("dropup-content-days2").style.display="block";
          }